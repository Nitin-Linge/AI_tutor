# app/pdf_handler.py
from PyPDF2 import PdfReader
import re

def extract_text_from_pdf(file_path: str, max_pages: int = 10) -> str:
    """Extract text from a PDF file, limiting to a maximum number of pages."""
    reader = PdfReader(file_path)
    text = ""
    for page_num in range(min(max_pages, len(reader.pages))):
        page = reader.pages[page_num]
        text += page.extract_text()

    # Clean up the extracted text
    processed_text = re.sub(r'\s+', ' ', text).strip()
    return processed_text