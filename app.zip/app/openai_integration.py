# app/openai_integration.py
import openai
from app.chromadb_integration import query_book_content

openai.api_key = "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"

def ask_openai_question(user_id: str, question: str, conversation_history: str = "") -> str:
    """Query OpenAI API using the relevant chunk from ChromaDB and user question."""
    
    # Retrieve the relevant chunk from ChromaDB based on the query
    relevant_chunk = query_book_content(user_id, question, conversation_history)
    if not relevant_chunk:
        return "No relevant content found in the book."

    # Construct the OpenAI message format
    messages = [
        {"role": "system", "content": "You are an AI tutor who provides helpful answers based on book content."},
        {"role": "user", "content": f"Here is the relevant content from the book:\n{relevant_chunk}\n\nQuestion: {question}"},
    ]
    
    # Add conversation history if any
    if conversation_history:
        messages.insert(1, {"role": "user", "content": conversation_history})

    # Call the Chat API instead of the old Completion API
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # or "gpt-4" based on your usage
        messages=messages,
        max_tokens=500,
        temperature=0.7,
    )
    
    # Extract the response from the assistant's reply
    return response['choices'][0]['message']['content'].strip()
