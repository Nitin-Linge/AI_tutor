# app/main.py
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends
from app.pdf_handler import extract_text_from_pdf
from app.openai_integration import ask_openai_question
from app.chromadb_integration import add_book_content_to_vdb, delete_collection
from app.models import QuestionRequest, QuestionResponse, UploadBookResponse
import shutil
import os

app = FastAPI()

BOOK_STORAGE = "uploaded_books"
if not os.path.exists(BOOK_STORAGE):
    os.mkdir(BOOK_STORAGE)

conversation_history = {}

@app.post("/upload_book/{user_id}", response_model=UploadBookResponse)
async def upload_book(user_id: str, file: UploadFile = File(...)):
    file_path = os.path.join(BOOK_STORAGE, file.filename)

    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    book_content = extract_text_from_pdf(file_path)
    if not book_content:
        raise HTTPException(status_code=400, detail="Failed to extract content from the book.")

    # Store the book content in ChromaDB as chunks
    add_book_content_to_vdb(user_id, book_content)

    return UploadBookResponse(message=f"Book '{file.filename}' uploaded and stored successfully!")

@app.post("/ask_question/{user_id}", response_model=QuestionResponse)
async def ask_question(user_id: str, question: QuestionRequest):
    global conversation_history
    if user_id not in conversation_history:
        conversation_history[user_id] = ""

    answer = ask_openai_question(user_id, question.question, conversation_history[user_id])
    conversation_history[user_id] += f"\n\nQuestion: {question.question}\nAnswer: {answer}"

    return QuestionResponse(answer=answer)

@app.delete("/remove_book/{user_id}", response_model=UploadBookResponse)
async def remove_book(user_id: str):
    """Remove book content for the user from ChromaDB."""
    delete_collection(user_id)
    if user_id in conversation_history:
        del conversation_history[user_id]
    return UploadBookResponse(message=f"Book content for user '{user_id}' removed successfully.")