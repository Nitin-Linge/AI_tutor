import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer

# Initialize the ChromaDB client
client = chromadb.PersistentClient(path="./chromadb/")

# Load a Sentence Transformer model (you can choose any suitable model)
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

def create_collection(user_id: str):
    """Create a collection for a specific user."""
    return client.create_collection(user_id)  # No embedding function needed as we handle embeddings ourselves

def get_collection(user_id: str):
    """Get the collection for a specific user."""
    try:
        return client.get_collection(user_id)
    except:
        return None

def delete_collection(user_id: str):
    """Delete the collection for a specific user."""
    try:
        client.delete_collection(user_id)
    except:
        pass

def add_book_content_to_vdb(user_id: str, book_content: str, chunk_size: int = 500):
    """Add book content to ChromaDB in chunks with Sentence Transformer embeddings."""
    collection = get_collection(user_id)
    if not collection:
        collection = create_collection(user_id)
    
    # Split the content into chunks of a specified size
    chunks = [book_content[i:i+chunk_size] for i in range(0, len(book_content), chunk_size)]
    
    # Generate embeddings for each chunk
    embeddings = model.encode(chunks).tolist()  # Convert embeddings to list format
    
    # Add each chunk as a separate document with unique IDs and embeddings
    for idx, chunk in enumerate(chunks):
        collection.add(
            documents=[chunk],
            ids=[f"{user_id}_chunk_{idx}"],
            embeddings=[embeddings[idx]]  # Pass the embedding for the chunk
        )

def query_book_content(user_id: str, query: str, conversation_history: str = ""):
    """Retrieve the relevant chunk from ChromaDB based on the user query."""
    collection = get_collection(user_id)
    if not collection:
        return None

    # Combine conversation history and user query
    combined_query = f"{conversation_history}\n{query}"

    # Generate embedding for the query
    query_embedding = model.encode([combined_query]).tolist()

    # Perform a similarity search to retrieve relevant chunks
    results = collection.query(
        query_embeddings=query_embedding,  # Use the embedding for the query
        n_results=1  # Retrieve the most relevant chunk
    )
    
    if results["documents"]:
        return results["documents"][0]  # Return the most relevant chunk
    return None
